function getColor(playerCount) {
  var colorToSet;
  if(playerCount === 1) {
    colorToSet = 'red';
  } else if (playerCount === 2) {
    colorToSet = 'blue';
  } else if (playerCount === 3) {
    colorToSet = 'yellow';
  } else if (playerCount > 3) {
    colorToSet = 'red';
    playerCount = 0;
  }
  return colorToSet;
}

function getPlayerNumber(playerCount) {
  playerCount++
  if (playerCount > 3) {
    playerCount = 1;
  }
  return playerCount;
}

$(document).ready(function(){
  var totalDotNum = 10000;
  var dotWrapper = $('.dot-wrapper');
  var dotHTML = '<div class="dot"><div class="line-1"></div><div class="line-2"></div></div>';
  var playerCount = 0;

  for(var i = 0; i < totalDotNum; i++) {
    dotWrapper.append(dotHTML);
  }

  $('.line-1').click(function(){
    playerCount = getPlayerNumber(playerCount);
    $(this).css({"background-color": getColor(playerCount),"opacity": "1"});
  });

  $('.line-2').click(function(){
    playerCount = getPlayerNumber(playerCount);
    $(this).css({"background-color": getColor(playerCount),"opacity": "1"});
  });
});