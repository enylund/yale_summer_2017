$(document).ready(function(){
	$( document ).on('scroll', function(event){
		var scrollPosition = $( document ).scrollTop();
		if(scrollPosition > 0 && scrollPosition < 1000) {
			console.log("0 to 1000");
		} else if (scrollPosition > 1000 && scrollPosition < 2000) {
			console.log("1000 to 2000");
		}
	});
});